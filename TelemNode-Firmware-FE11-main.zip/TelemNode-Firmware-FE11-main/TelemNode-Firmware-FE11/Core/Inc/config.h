/*
 * config.h
 *
 *  Created on: Apr 12, 2024
 *      Author: leoja
 */

#ifndef INC_CONFIG_H_
#define INC_CONFIG_H_

#define LOOP_PERIOD_MS 100
#define WHEEL_SPEED_LOOPS 5



#endif /* INC_CONFIG_H_ */
